export class LoginResponse{
    success:boolean; 
    token = "hcvcbfsdkzbcvjhvbf.wadihcufirued.123gh";
}