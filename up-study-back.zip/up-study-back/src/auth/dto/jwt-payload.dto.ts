export interface JwtPayload{
    id:string;
    username:string;
    email:string;
    name:string;
    password:string;
    creationDate:Date;
}