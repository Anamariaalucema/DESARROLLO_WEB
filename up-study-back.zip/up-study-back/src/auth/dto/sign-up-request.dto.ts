import { PartialType } from "@nestjs/mapped-types"
import { AuthDto } from "./auth.dto"

export class SignUpDto extends PartialType(AuthDto){
    username:string 
    password:string 
    email:string 
    name:string 
}