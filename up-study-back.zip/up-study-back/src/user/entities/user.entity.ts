import { Publi } from "src/publi/entities/publi.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, Unique } from "typeorm";

@Entity('users')
export class User {

    @PrimaryGeneratedColumn("uuid")
    id:string;

    @Column({
        type:'varchar',
        unique:true
    })
    username:string;

    @Column({type:'varchar'})
    email:string;

    @Column({type:'varchar'})
    name:string;

    @Column({type:'varchar'})
    password:string;

    @CreateDateColumn({name:'create_date'})
    creationDate:Date;


    @OneToMany(() => Publi, (publi) => publi.user, {onDelete:"CASCADE"}) // ← "publi.user" es correcto
    publis: Publi[];
}
