import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards } from '@nestjs/common';
import { PubliService } from './publi.service';
import { CreatePubliDto } from './dto/create-publi.dto';
import { AuthGuard } from 'src/auth/guards/auth/auth.guard';

@Controller('publi')
export class PubliController {
  constructor(private readonly publiService: PubliService) {}

  @UseGuards(AuthGuard)
  @Post()
  create(@Body() createPubliDto: CreatePubliDto) {
    return this.publiService.create(createPubliDto);
  }

  @Get()
  findAll() {
    return this.publiService.findAll();
  }

  @Get(':userId')
  @UseGuards(AuthGuard)
  findAllByUser(@Param('userId') userId: string) {
    return this.publiService.findAllByUser(userId);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.publiService.remove(+id);
  }
}