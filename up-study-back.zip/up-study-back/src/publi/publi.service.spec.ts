import { Test, TestingModule } from '@nestjs/testing';
import { PubliService } from './publi.service';

describe('PubliService', () => {
  let service: PubliService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [PubliService],
    }).compile();

    service = module.get<PubliService>(PubliService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});
