import { PartialType } from '@nestjs/mapped-types';
import { CreatePubliDto } from './create-publi.dto';

export class UpdatePubliDto extends PartialType(CreatePubliDto) {}
