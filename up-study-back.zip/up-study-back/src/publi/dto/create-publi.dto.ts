export class CreatePubliDto {
    url:string;
    userId:string;
    name:string; 
    keywords:string;
    creation:string;
    institution:string;
    numberpages:string;
    academicarea:string; 
    sinopsis:string;
}
