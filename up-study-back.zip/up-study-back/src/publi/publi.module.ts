import { Module } from '@nestjs/common';
import { PubliService } from './publi.service';
import { PubliController } from './publi.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from 'src/user/entities/user.entity';
import { Publi } from './entities/publi.entity';

@Module({
  imports: [TypeOrmModule.forFeature([User, Publi])],
  controllers: [PubliController],
  providers: [PubliService],
})
export class PubliModule {}
