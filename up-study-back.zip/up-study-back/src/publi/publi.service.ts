import { Injectable } from '@nestjs/common';
import { CreatePubliDto } from './dto/create-publi.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Publi } from './entities/publi.entity';
import { Repository } from 'typeorm';

@Injectable()
export class PubliService {

  constructor(@InjectRepository(Publi) private publiRepository: Repository<Publi>){}

  create(createPubliDto: CreatePubliDto) {
    const publication = this.publiRepository.create({
      url:createPubliDto.url,
      name:createPubliDto.name, 
      keywords:createPubliDto.keywords, 
      creation:createPubliDto.creation,
      institution:createPubliDto.institution,
      numberpages:createPubliDto.numberpages,
      academicarea:createPubliDto.academicarea,
      sinopsis:createPubliDto.sinopsis,
      user:{
        id:createPubliDto.userId
      }
    })
    return this.publiRepository.save(publication);
  }

  findAll() {
    return this.publiRepository.find();
  }

  findAllByUser(userId:string) {
    return this.publiRepository.find({
      where:{user:{id:userId}},
      select:{
        id:true,
        url:true,
        name:true, 
        keywords:true, 
        creation:true,
        institution:true,
        numberpages:true,
        academicarea:true,
        sinopsis:true,
        user:{username:true}
      },
      relations:{user:true}
    });
  }


  remove(id: number) {
    return `This action removes a #${id} user`;
  }
}