import { Test, TestingModule } from '@nestjs/testing';
import { PubliController } from './publi.controller';
import { PubliService } from './publi.service';

describe('PubliController', () => {
  let controller: PubliController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PubliController],
      providers: [PubliService],
    }).compile();

    controller = module.get<PubliController>(PubliController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
