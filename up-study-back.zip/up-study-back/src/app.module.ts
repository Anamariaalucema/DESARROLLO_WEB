import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { AuthModule } from './auth/auth.module';
import { PubliModule } from './publi/publi.module';
import { TypeOrmModule } from '@nestjs/typeorm';
import { User } from './user/entities/user.entity';
import { Publi } from './publi/entities/publi.entity';

@Module({
  imports: [TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'aws-0-us-east-2.pooler.supabase.com',
      port: 6543,
      username: 'postgres.ztoggyqqupstpynfqsqa',
      password: '?QJ$-9inmG2bQu!',
      database: 'postgres',
      entities: [User, Publi],
      synchronize: true, // solo en desarrollo
    }),
    UserModule, 
    AuthModule, 
    PubliModule],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
