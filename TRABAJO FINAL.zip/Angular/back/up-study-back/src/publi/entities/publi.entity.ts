import { User } from "src/user/entities/user.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn } from "typeorm";

@Entity('publi')
export class Publi {

    @PrimaryGeneratedColumn("uuid")
    id:string ; 

    @Column({type:'varchar'})
    name:string; 

    @Column({type:'varchar'})
    keywords:string; 

    @Column({type:'varchar'})
    creation:string; 

    @Column({type:'varchar'})
    institution:string; 

    @Column({type:'varchar'})
    numberpages:string; 

    @Column({type:'varchar'})
    academicarea:string; 

    @Column({type:'varchar'})
    sinopsis:string; 

    @Column({type:'varchar'})
    url:string; 

    @CreateDateColumn({name:'create_date'})
    creationDate:Date;

    @ManyToOne(()=> User, (user)=>user.publis)
    user:User;  
}
